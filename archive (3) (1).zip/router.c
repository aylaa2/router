#include "queue.h"
#include "lib.h"
#include "list.h"
#include "protocols.h"
#include <arpa/inet.h> /* ntoh, hton and inet_ functions */

#include <stdlib.h> // For qsort()
#include <string.h>
#include <arpa/inet.h>  // For inet_pton

/* Routing table */
struct route_table_entry *rtable;
int rtable_len;

/* Mac table */
struct arp_table_entry *arp_table;
int arp_table_len;


// from lab 4
struct route_table_entry *get_best_route(uint32_t ip_dest) {
	for (int  i = 0; i < rtable_len ; i++) {
		if((rtable[i].mask & ip_dest) == rtable[i].prefix) {
			return &rtable[i];
		}
	}
	return NULL;
}

// from lab4 solution
struct arp_table_entry *get_arp_entry(uint32_t given_ip) {
	for (int i = 0; i < arp_table_len; i++) {
		if(arp_table[i].ip == given_ip) {
			return &arp_table[i];
		}
	}

	return NULL;
}

// Setup Ethernet header
void setup_ethernet_header(struct ether_header *eth, struct ether_header *orig_eth, int interface) {
    eth->ether_type = htons(ETHERTYPE_IP);
    memcpy(eth->ether_dhost, orig_eth->ether_shost, ETH_ALEN);
    get_interface_mac(interface, eth->ether_shost);
}

// Setup IP header
void setup_ip_header(struct iphdr *ip, struct iphdr *orig_ip, int payload_size) {
    // Initialize protocol and checksum fields first
    ip->protocol = IPPROTO_ICMP;
    ip->check = 0;  // Set to zero before calculating the checksum

    // Setup IP addresses which are often variable parts
    ip->saddr = orig_ip->daddr;
    ip->daddr = orig_ip->saddr;

    // Setup static fields of the IP header
    ip->version = 4;
    ip->ihl = 5;
    ip->tos = 0;
    ip->ttl = 64;
    ip->frag_off = 0;

    // Calculate total length last before setting the checksum
    ip->tot_len = htons(sizeof(struct iphdr) + payload_size);
    
    // Calculate checksum after all other fields are set
    ip->check = htons(checksum((uint16_t *)ip, sizeof(struct iphdr)));
}


// General ICMP packet sender function
void send_icmp_packet(int interface, struct ether_header *eth_hdr, struct iphdr *ip_hdr, int icmp_type, int icmp_code, int ip_payload_size) {
    int packet_size = sizeof(struct ether_header) + sizeof(struct iphdr) + sizeof(struct icmphdr);
    char *packet = malloc(packet_size);

    struct ether_header *eth = (struct ether_header *)packet;
    setup_ethernet_header(eth, eth_hdr, interface);

    struct iphdr *ip = (struct iphdr *)(packet + sizeof(struct ether_header));
    setup_ip_header(ip, ip_hdr, sizeof(struct icmphdr));

    struct icmphdr *icmp = (struct icmphdr *)(packet + sizeof(struct ether_header) + sizeof(struct iphdr));
    icmp->type = icmp_type;
    icmp->code = icmp_code;
    icmp->checksum = 0;
    icmp->checksum = htons(checksum((uint16_t *)icmp, sizeof(struct icmphdr)));

    send_to_link(interface, packet, packet_size);
    free(packet);
}


//ipv4 protocol
void ipv4protocol(struct ether_header *eth_hdr, int interface, size_t packet_len, char *packet_buffer) {
    struct iphdr *ip_hdr = (struct iphdr *)(packet_buffer + sizeof(struct ether_header));

    // Verify IP header's checksum
    uint16_t orig_checksum = ip_hdr->check;
    ip_hdr->check = 0;
    if (checksum((uint16_t *)ip_hdr, sizeof(struct iphdr)) != ntohs(orig_checksum)) {
        printf("IP header checksum does not exist\n");
        return;
    }
    

	// Verific daca adresa IP destinatie este adresa mea, daca da, trimit un pachet ICMP de tip echo reply
	if (ip_hdr->daddr == inet_addr(get_interface_ip(interface))) {
		send_icmp_packet(interface, eth_hdr, ip_hdr, ICMP_ECHOREPLY, 0, 0);
		return;
	}

    // Check TTL, and send a packet an icmp packet (time exceeded)
    if (ip_hdr->ttl <= 1) {
        printf("TTL expired\n");
		send_icmp_packet(interface, eth_hdr, ip_hdr, ICMP_TIME_EXCEEDED, 0, 0);
        return;
    }

    // Decrement TTL
    ip_hdr->ttl--;
    ip_hdr->check = htons(checksum((uint16_t *)ip_hdr, sizeof(struct iphdr)));

    // Find the best route
    struct route_table_entry *route = get_best_route(ip_hdr->daddr);
    if (!route) {
        printf("No route found\n");
		// send an icmp packet (destination unreach) + ignore it
		send_icmp_packet(interface, eth_hdr, ip_hdr, ICMP_DEST_UNREACH, 0, 0);
        return;
    }

    // Check ARP entry for the next-hop IP address
    struct arp_table_entry *arp_entry = get_arp_entry(route->next_hop);
    if (!arp_entry) {
        printf("ARP entry not found\n");
        // Potentially enqueue the packet for later transmission
        return;
    }

    // Set destination MAC address
    memcpy(eth_hdr->ether_dhost, arp_entry->mac, ETH_ALEN);

    // Send packet
    send_to_link(route->interface, packet_buffer, packet_len);
}

// Comparison function for qsort
int compare_routes(const void *a, const void *b) {
    const struct route_table_entry *entry1 = (const struct route_table_entry *)a;
    const struct route_table_entry *entry2 = (const struct route_table_entry *)b;

    // Convert network byte order to host byte order for comparison
    uint32_t addr1 = ntohl(entry1->prefix & entry1->mask);
    uint32_t addr2 = ntohl(entry2->prefix & entry2->mask);

    if (addr1 != addr2) {
        return (addr1 > addr2) ? -1 : 1;
    }

    // If addresses are the same, sort by mask, larger mask comes first (more specific subnet)
    uint32_t mask1 = ntohl(entry1->mask);
    uint32_t mask2 = ntohl(entry2->mask);
    if (mask1 != mask2) {
        return (mask1 > mask2) ? -1 : 1;
    }

    return 0;
}


// Function pointer type for protocol handlers
typedef void (*protocol_handler_t)(struct ether_header *eth_hdr, int interface, size_t packet_len, char *packet);

// Struct to map ether_type to the appropriate function
typedef struct {
    uint16_t ether_type;
    protocol_handler_t handler;
} ether_type_handler;


// aici doar adaug protocoale pe care le am
ether_type_handler handlers[] = {
    { ETHERTYPE_IP, ipv4protocol },
    // { ETHERTYPE_ARP, handle_arp_packet },
    { 0, NULL } // End of array marker
};

protocol_handler_t find_handler(uint16_t ether_type) {
    for (int i = 0; handlers[i].handler != NULL; i++) {
        if (ntohs(ether_type) == handlers[i].ether_type) {
            return handlers[i].handler;
        }
    }
    return NULL; // Return NULL if no handler is found
}

int main(int argc, char *argv[])
{
	char buf[MAX_PACKET_LEN];
	
	// Do not modify this line
	init(argc - 2, argv + 2);

	/* Code to allocate the arp and route tables */
	rtable = malloc(sizeof(struct route_table_entry) * 100000);
 	DIE(rtable == NULL, "failed to allocate memory");
	rtable_len = read_rtable(argv[1], rtable);
	qsort(rtable, rtable_len, sizeof(struct route_table_entry), compare_routes);

	arp_table = malloc(30 * sizeof(struct arp_table_entry));
	DIE(arp_table == NULL, "failed to allocate ");
	arp_table_len = parse_arp_table("arp_table.txt", arp_table);

	while (1) {

		int interface;
		size_t len;

		interface = recv_from_any_link(buf, &len);
		DIE(interface < 0, "recv_from_any_links");

		struct ether_header *eth_hdr = (struct ether_header *) buf;
		
		/* Check if we got an IPv4 packet */
		if (eth_hdr->ether_type != ntohs(ETHERTYPE_IP)) {
			printf("Ignored non-IPv4 packet\n");
			continue;
		}
		
		protocol_handler_t handler = find_handler(eth_hdr->ether_type);

		if (handler) {
			handler(eth_hdr, interface, len, buf);
		} else {
			printf("No handler found for ether_type 0x%04x\n", ntohs(eth_hdr->ether_type));
		}

	}

	/* Free allocated memory (optional, depending on program requirements) */
    free(rtable);
    free(arp_table);
}